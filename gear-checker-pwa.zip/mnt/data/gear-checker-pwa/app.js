const STORAGE_KEY = 'gear-check-v1';
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const today = () => new Date().toISOString().slice(0,10);

const seedData = () => {
  const bags = [
    { id: uid(), name: 'Rucsac cameră', type: 'backpack', notes: 'Setup rapid pentru cameră + lentile' },
    { id: uid(), name: 'Troller lumini', type: 'trolley', notes: 'Lumini, stative, alimentare' },
    { id: uid(), name: 'Geantă audio', type: 'audio', notes: 'Microfoane, lavaliere, cabluri audio' },
    { id: uid(), name: 'Pouch cabluri', type: 'pouch', notes: 'HDMI, USB-C, adaptoare, prelungitoare' },
    { id: uid(), name: 'Case dronă', type: 'case', notes: 'Dronă, baterii, telecomandă' },
    { id: uid(), name: 'Portbagaj', type: 'car', notes: 'Backup, stative mari, consumabile' }
  ];
  const bag = name => bags.find(b => b.name === name)?.id || '';
  const gear = [
    ['Sony FX3','Camera',1,'Rucsac cameră','available','Main camera, S-Log3'],
    ['Sony A7S III','Camera',1,'Rucsac cameră','available','B-cam / backup'],
    ['Sony 24-70mm GM II','Lens',1,'Rucsac cameră','available','Main versatile lens'],
    ['Laowa 10mm','Lens',1,'Rucsac cameră','available','Real estate / wide shots'],
    ['Sony Zeiss 50mm f/1.4','Lens',1,'Rucsac cameră','available','Portrait / detail'],
    ['Sigma 85mm Art','Lens',1,'Rucsac cameră','available','Portrait / cinematic details'],
    ['Atomos Ninja V','Monitor/Recorder',1,'Rucsac cameră','available','Monitor + recorder'],
    ['DJI Ronin RS3','Stabilizare',1,'Portbagaj','available','Gimbal'],
    ['SD Cards','Storage',6,'Rucsac cameră','available','Formatate înainte de shoot'],
    ['FX3 / NP-FZ100 baterii','Power',6,'Rucsac cameră','available','Încărcate full'],
    ['V-Mount SmallRig VB99 Pro','Power',1,'Rucsac cameră','available','Rig power'],
    ['PicoGear PicoMic 2 Pro','Audio',1,'Geantă audio','available','Wireless mic kit'],
    ['Shotgun mic','Audio',1,'Geantă audio','available','Backup audio'],
    ['SmallRig RC100B','Light',1,'Troller lumini','available','Key/accent light'],
    ['Nanlite Forza 300','Light',1,'Troller lumini','available','Big key light'],
    ['Godox BG02','Light',1,'Troller lumini','available','Tube / accent'],
    ['MixPad 150','Light',1,'Troller lumini','available','Soft light'],
    ['Light stands','Grip',3,'Troller lumini','available','Stative lumini'],
    ['Tripod video','Grip',1,'Portbagaj','available','Locked shots'],
    ['Smoke machine','FX',1,'Portbagaj','available','Atmosphere'],
    ['HDMI cables','Cables',3,'Pouch cabluri','available','Atomos/camera'],
    ['USB-C cables','Cables',4,'Pouch cabluri','available','Power/data'],
    ['Chargers','Power',4,'Pouch cabluri','available','Camera/light/audio chargers'],
    ['Gaffer tape','Consumables',1,'Portbagaj','available','Always useful']
  ].map(([name,category,quantity,bagName,status,notes]) => ({ id: uid(), name, category, quantity, bagId: bag(bagName), status, notes }));
  const g = name => gear.find(x => x.name === name)?.id;
  const templates = [
    { name: 'Real Estate', notes: 'Wide, clean, fast walkthrough', items: ['Sony FX3','Laowa 10mm','Sony 24-70mm GM II','DJI Ronin RS3','SD Cards','FX3 / NP-FZ100 baterii','HDMI cables','USB-C cables','Chargers'] },
    { name: 'Corporate', notes: 'Interview + b-roll', items: ['Sony FX3','Sony A7S III','Sony 24-70mm GM II','Sony Zeiss 50mm f/1.4','PicoGear PicoMic 2 Pro','Shotgun mic','SmallRig RC100B','Nanlite Forza 300','Light stands','Tripod video','SD Cards','FX3 / NP-FZ100 baterii','Chargers'] },
    { name: 'Restaurant', notes: 'Food, vibe, details', items: ['Sony FX3','Sony 24-70mm GM II','Sigma 85mm Art','DJI Ronin RS3','SmallRig RC100B','Godox BG02','SD Cards','FX3 / NP-FZ100 baterii','Gaffer tape'] },
    { name: 'Rapid Basket', notes: 'Match vertical highlights', items: ['Sony FX3','Sony 24-70mm GM II','Atomos Ninja V','V-Mount SmallRig VB99 Pro','SD Cards','FX3 / NP-FZ100 baterii','HDMI cables','USB-C cables','Chargers'] },
    { name: 'Product Video', notes: 'Controlled cinematic product shoot', items: ['Sony FX3','Sony 24-70mm GM II','Sony Zeiss 50mm f/1.4','Sigma 85mm Art','SmallRig RC100B','Nanlite Forza 300','Godox BG02','MixPad 150','Light stands','Tripod video','Smoke machine','Gaffer tape'] },
    { name: 'Wedding / Botez', notes: 'Long day, redundancy, audio', items: ['Sony FX3','Sony A7S III','Sony 24-70mm GM II','Sony Zeiss 50mm f/1.4','Sigma 85mm Art','DJI Ronin RS3','PicoGear PicoMic 2 Pro','Shotgun mic','SD Cards','FX3 / NP-FZ100 baterii','V-Mount SmallRig VB99 Pro','Chargers','Gaffer tape'] }
  ].map(t => ({ id: uid(), name: t.name, notes: t.notes, itemIds: t.items.map(g).filter(Boolean) }));
  return { bags, gear, templates, sessions: [], settings: { firstRun: false } };
};

let state = load();
let activeTab = 'dashboard';
let currentSessionId = null;

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || seedData(); }
  catch { return seedData(); }
}
function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function byId(arr, id) { return arr.find(x => x.id === id); }
function bagName(id) { return byId(state.bags, id)?.name || 'Fără bagaj'; }
function escapeHtml(str='') { return String(str).replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s])); }

const view = document.getElementById('view');
const title = document.getElementById('screenTitle');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalBody = document.getElementById('modalBody');
const importFile = document.getElementById('importFile');

document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
  activeTab = btn.dataset.tab;
  currentSessionId = null;
  render();
}));
document.getElementById('quickAddBtn').addEventListener('click', () => {
  if (activeTab === 'bags') openBagForm();
  else if (activeTab === 'templates') openTemplateForm();
  else if (activeTab === 'sessions') openNewSession();
  else openGearForm();
});
document.getElementById('closeModalBtn').addEventListener('click', () => modal.close());

function render() {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === activeTab));
  const map = { dashboard: renderDashboard, inventory: renderInventory, bags: renderBags, templates: renderTemplates, sessions: renderSessions };
  map[activeTab]();
}

function renderDashboard() {
  title.textContent = 'Gear Check';
  const total = state.gear.length;
  const bags = state.bags.length;
  const templates = state.templates.length;
  const open = state.sessions.filter(s => !s.completed).length;
  view.innerHTML = `
    <section class="hero stack">
      <h2>Nu mai pleci fără cabluri, baterii sau carduri.</h2>
      <p class="muted">Inventory + bagaje + checklist-uri pentru filmări. Totul local pe iPhone.</p>
      <button class="primary" onclick="openNewSession()">＋ New Shoot Checklist</button>
    </section>
    <div class="grid two" style="margin-top:14px">
      <div class="card kpi"><span class="muted">Gear items</span><strong>${total}</strong></div>
      <div class="card kpi"><span class="muted">Bagaje</span><strong>${bags}</strong></div>
      <div class="card kpi"><span class="muted">Template-uri</span><strong>${templates}</strong></div>
      <div class="card kpi"><span class="muted">Sesiuni active</span><strong>${open}</strong></div>
    </div>
    <div class="section-title"><h3>Acțiuni rapide</h3></div>
    <div class="grid">
      <button class="secondary" onclick="openGearForm()">Adaugă echipament</button>
      <button class="secondary" onclick="openBagForm()">Adaugă bagaj/case</button>
      <button class="secondary" onclick="openTemplateForm()">Creează template</button>
      <div class="footer-actions">
        <button class="ghost" onclick="exportBackup()">Export backup</button>
        <button class="ghost" onclick="importFile.click()">Import backup</button>
      </div>
    </div>
    <div class="section-title"><h3>Ultimele sesiuni</h3><button class="ghost tiny" onclick="activeTab='sessions';render()">Vezi toate</button></div>
    ${sessionList(state.sessions.slice(-3).reverse())}
  `;
}

function renderInventory(filter='') {
  title.textContent = 'Inventory';
  const items = state.gear.filter(item => [item.name,item.category,item.notes,bagName(item.bagId)].join(' ').toLowerCase().includes(filter.toLowerCase()));
  const categories = [...new Set(state.gear.map(i => i.category))].sort();
  view.innerHTML = `
    <input class="search" placeholder="Caută gear, categorie, bagaj..." value="${escapeHtml(filter)}" oninput="renderInventory(this.value)" />
    <div class="row"><span class="pill">${items.length} iteme</span><button class="primary tiny" onclick="openGearForm()">＋ Gear</button></div>
    <div class="section-title"><h3>Pe categorii</h3></div>
    <div class="stack">${categories.map(cat => {
      const catItems = items.filter(i => i.category === cat);
      if (!catItems.length) return '';
      return `<div class="card flat"><div class="row"><h3>${escapeHtml(cat)}</h3><span class="pill">${catItems.length}</span></div><div class="list">${catItems.map(gearItemRow).join('')}</div></div>`;
    }).join('') || empty('Nu ai încă echipament în inventory.')}</div>
  `;
}

function gearItemRow(item) {
  const statusClass = item.status === 'available' ? 'ok' : item.status === 'missing' ? 'warn' : '';
  return `<div class="item">
    <div class="item-left" onclick="openGearForm('${item.id}')">
      <div class="item-title">${escapeHtml(item.name)} ${item.quantity > 1 ? `×${item.quantity}` : ''}</div>
      <div class="item-sub">${escapeHtml(bagName(item.bagId))} · ${escapeHtml(item.notes || 'fără notițe')}</div>
    </div>
    <span class="pill ${statusClass}">${escapeHtml(item.status)}</span>
  </div>`;
}

function renderBags() {
  title.textContent = 'Bagaje';
  view.innerHTML = `
    <div class="row"><span class="pill">${state.bags.length} bagaje</span><button class="primary tiny" onclick="openBagForm()">＋ Bagaj</button></div>
    <div class="grid" style="margin-top:12px">${state.bags.map(b => {
      const count = state.gear.filter(g => g.bagId === b.id).length;
      return `<div class="card stack">
        <div class="row"><div><h2>${escapeHtml(b.name)}</h2><p class="muted">${escapeHtml(b.notes || b.type || '')}</p></div><span class="pill accent">${count} iteme</span></div>
        <div class="list">${state.gear.filter(g => g.bagId === b.id).slice(0,4).map(g => `<div class="item"><div><div class="item-title">${escapeHtml(g.name)}</div><div class="item-sub">${escapeHtml(g.category)}</div></div></div>`).join('') || '<p class="empty">Gol momentan.</p>'}</div>
        <div class="footer-actions"><button class="ghost" onclick="openBagForm('${b.id}')">Editează</button><button class="danger" onclick="deleteBag('${b.id}')">Șterge</button></div>
      </div>`;
    }).join('') || empty('Nu ai bagaje definite.')}</div>`;
}

function renderTemplates() {
  title.textContent = 'Templates';
  view.innerHTML = `
    <div class="row"><span class="pill">${state.templates.length} template-uri</span><button class="primary tiny" onclick="openTemplateForm()">＋ Template</button></div>
    <div class="grid" style="margin-top:12px">${state.templates.map(t => {
      return `<div class="card stack">
        <div class="row"><div><h2>${escapeHtml(t.name)}</h2><p class="muted">${escapeHtml(t.notes || '')}</p></div><span class="pill accent">${t.itemIds.length} iteme</span></div>
        <button class="primary" onclick="createSession('${t.id}')">Pornește checklist</button>
        <div class="footer-actions"><button class="ghost" onclick="openTemplateForm('${t.id}')">Editează</button><button class="danger" onclick="deleteTemplate('${t.id}')">Șterge</button></div>
      </div>`;
    }).join('') || empty('Nu ai template-uri.')}</div>`;
}

function renderSessions() {
  title.textContent = 'Sesiuni';
  if (currentSessionId) return renderSessionDetail(currentSessionId);
  view.innerHTML = `
    <button class="primary" onclick="openNewSession()">＋ New Shoot Checklist</button>
    <div class="section-title"><h3>Active</h3></div>
    ${sessionList(state.sessions.filter(s => !s.completed).reverse())}
    <div class="section-title"><h3>Finalizate</h3></div>
    ${sessionList(state.sessions.filter(s => s.completed).reverse())}
  `;
}

function sessionList(sessions) {
  if (!sessions.length) return empty('Nicio sesiune aici momentan.');
  return `<div class="list">${sessions.map(s => {
    const pack = progress(s.packItems);
    const ret = progress(s.returnItems);
    return `<div class="item" onclick="currentSessionId='${s.id}';activeTab='sessions';render()">
      <div class="item-left"><div class="item-title">${escapeHtml(s.name)}</div><div class="item-sub">${escapeHtml(s.date)} · Packed ${pack}% · Return ${ret}%</div></div>
      <span class="pill ${s.completed ? 'ok' : ''}">${s.completed ? 'done' : 'active'}</span>
    </div>`;
  }).join('')}</div>`;
}

function renderSessionDetail(id) {
  const s = byId(state.sessions, id);
  if (!s) { currentSessionId = null; return renderSessions(); }
  title.textContent = s.name;
  const packPct = progress(s.packItems), returnPct = progress(s.returnItems);
  const mode = s.mode || 'pack';
  const items = mode === 'pack' ? s.packItems : s.returnItems;
  const missing = items.filter(i => !i.checked);
  view.innerHTML = `
    <button class="ghost tiny" onclick="currentSessionId=null;renderSessions()">‹ Înapoi</button>
    <section class="card stack" style="margin-top:10px">
      <div class="row"><div><h2>${escapeHtml(s.name)}</h2><p class="muted">${escapeHtml(s.date)} · ${mode === 'pack' ? 'Checklist plecare' : 'Checklist întoarcere'}</p></div><span class="pill accent">${mode === 'pack' ? packPct : returnPct}%</span></div>
      <div class="progress"><div style="width:${mode === 'pack' ? packPct : returnPct}%"></div></div>
      <div class="footer-actions"><button class="${mode==='pack'?'primary':'secondary'}" onclick="setSessionMode('${s.id}','pack')">Plecare</button><button class="${mode==='return'?'primary':'secondary'}" onclick="setSessionMode('${s.id}','return')">Întoarcere</button></div>
    </section>
    ${missing.length ? `<div class="section-title"><h3>Lipsesc / nebifate</h3><span class="pill warn">${missing.length}</span></div><div class="list">${missing.map(i => checklistRow(s.id, i, mode, true)).join('')}</div>` : `<div class="card flat" style="margin-top:14px"><p class="empty">Totul bifat. Frumos.</p></div>`}
    <div class="section-title"><h3>Toate itemele</h3></div>
    <div class="list">${items.map(i => checklistRow(s.id, i, mode)).join('')}</div>
    <div class="footer-actions"><button class="ghost" onclick="toggleAll('${s.id}','${mode}',true)">Bifează tot</button><button class="ghost" onclick="toggleAll('${s.id}','${mode}',false)">Reset</button></div>
    <div class="footer-actions"><button class="secondary" onclick="completeSession('${s.id}')">Marchează finalizat</button><button class="danger" onclick="deleteSession('${s.id}')">Șterge sesiunea</button></div>
  `;
}

function checklistRow(sessionId, ci, mode, compact=false) {
  const item = byId(state.gear, ci.gearId);
  if (!item) return '';
  return `<div class="item" onclick="toggleChecklist('${sessionId}','${ci.id}','${mode}')">
    <div class="checkbox ${ci.checked ? 'checked' : ''}">${ci.checked ? '✓' : ''}</div>
    <div class="item-left"><div class="item-title">${escapeHtml(item.name)} ${item.quantity > 1 ? `×${item.quantity}` : ''}</div><div class="item-sub">${escapeHtml(item.category)} · ${escapeHtml(bagName(item.bagId))}${compact ? '' : ` · ${escapeHtml(item.notes || '')}`}</div></div>
  </div>`;
}

function progress(items) {
  if (!items || !items.length) return 0;
  return Math.round(items.filter(i => i.checked).length / items.length * 100);
}
function empty(text) { return `<div class="card flat"><p class="empty">${escapeHtml(text)}</p></div>`; }

function openModal(name, html) {
  modalTitle.textContent = name;
  modalBody.innerHTML = html;
  modal.showModal();
}

function openGearForm(id='') {
  const item = byId(state.gear, id) || { name:'', category:'Camera', quantity:1, bagId: state.bags[0]?.id || '', status:'available', notes:'' };
  openModal(id ? 'Editează gear' : 'Adaugă gear', `
    <div class="form-grid">
      <label>Nume<input id="fName" value="${escapeHtml(item.name)}" placeholder="Sony FX3" /></label>
      <label>Categorie<input id="fCategory" value="${escapeHtml(item.category)}" placeholder="Camera, Lens, Audio..." /></label>
      <label>Cantitate<input id="fQty" type="number" min="1" value="${item.quantity || 1}" /></label>
      <label>Bagaj<select id="fBag">${state.bags.map(b => `<option value="${b.id}" ${b.id===item.bagId?'selected':''}>${escapeHtml(b.name)}</option>`).join('')}</select></label>
      <label>Status<select id="fStatus">${['available','missing','service','borrowed'].map(s => `<option ${s===item.status?'selected':''}>${s}</option>`).join('')}</select></label>
      <label>Notițe<textarea id="fNotes">${escapeHtml(item.notes || '')}</textarea></label>
      <button class="primary" type="button" onclick="saveGear('${id}')">Salvează</button>
      ${id ? `<button class="danger" type="button" onclick="deleteGear('${id}')">Șterge</button>` : ''}
    </div>`);
}
function saveGear(id='') {
  const payload = { name: fName.value.trim(), category: fCategory.value.trim() || 'Other', quantity: Math.max(1, Number(fQty.value||1)), bagId: fBag.value, status: fStatus.value, notes: fNotes.value.trim() };
  if (!payload.name) return alert('Pune un nume.');
  if (id) Object.assign(byId(state.gear, id), payload); else state.gear.push({ id: uid(), ...payload });
  save(); modal.close(); render();
}
function deleteGear(id) {
  if (!confirm('Ștergi echipamentul?')) return;
  state.gear = state.gear.filter(g => g.id !== id);
  state.templates.forEach(t => t.itemIds = t.itemIds.filter(x => x !== id));
  save(); modal.close(); render();
}

function openBagForm(id='') {
  const bag = byId(state.bags, id) || { name:'', type:'case', notes:'' };
  openModal(id ? 'Editează bagaj' : 'Adaugă bagaj', `
    <div class="form-grid">
      <label>Nume<input id="bName" value="${escapeHtml(bag.name)}" placeholder="Rucsac cameră" /></label>
      <label>Tip<input id="bType" value="${escapeHtml(bag.type || '')}" placeholder="backpack, trolley, case..." /></label>
      <label>Notițe<textarea id="bNotes">${escapeHtml(bag.notes || '')}</textarea></label>
      <button class="primary" type="button" onclick="saveBag('${id}')">Salvează</button>
    </div>`);
}
function saveBag(id='') {
  const payload = { name: bName.value.trim(), type: bType.value.trim(), notes: bNotes.value.trim() };
  if (!payload.name) return alert('Pune un nume.');
  if (id) Object.assign(byId(state.bags, id), payload); else state.bags.push({ id: uid(), ...payload });
  save(); modal.close(); render();
}
function deleteBag(id) {
  if (!confirm('Ștergi bagajul? Itemele rămân fără bagaj.')) return;
  state.bags = state.bags.filter(b => b.id !== id);
  state.gear.forEach(g => { if (g.bagId === id) g.bagId = ''; });
  save(); render();
}

function openTemplateForm(id='') {
  const t = byId(state.templates, id) || { name:'', notes:'', itemIds:[] };
  openModal(id ? 'Editează template' : 'Adaugă template', `
    <div class="form-grid">
      <label>Nume<input id="tName" value="${escapeHtml(t.name)}" placeholder="Real Estate" /></label>
      <label>Notițe<textarea id="tNotes">${escapeHtml(t.notes || '')}</textarea></label>
      <div><p class="muted" style="margin-bottom:8px;font-weight:800">Iteme incluse</p><div class="list" style="max-height:310px;overflow:auto">${state.gear.map(g => `<label class="item" style="grid-template-columns:auto 1fr;display:grid"><input type="checkbox" class="tGear" value="${g.id}" ${t.itemIds.includes(g.id)?'checked':''} style="width:24px" /><span><b>${escapeHtml(g.name)}</b><br><small class="muted">${escapeHtml(g.category)} · ${escapeHtml(bagName(g.bagId))}</small></span></label>`).join('')}</div></div>
      <button class="primary" type="button" onclick="saveTemplate('${id}')">Salvează</button>
    </div>`);
}
function saveTemplate(id='') {
  const payload = { name: tName.value.trim(), notes: tNotes.value.trim(), itemIds: [...document.querySelectorAll('.tGear:checked')].map(x => x.value) };
  if (!payload.name) return alert('Pune un nume.');
  if (id) Object.assign(byId(state.templates, id), payload); else state.templates.push({ id: uid(), ...payload });
  save(); modal.close(); render();
}
function deleteTemplate(id) {
  if (!confirm('Ștergi template-ul?')) return;
  state.templates = state.templates.filter(t => t.id !== id);
  save(); render();
}

function openNewSession() {
  openModal('New Shoot Checklist', `
    <div class="form-grid">
      <label>Nume sesiune<input id="sName" value="Filmare ${today()}" /></label>
      <label>Data<input id="sDate" type="date" value="${today()}" /></label>
      <p class="muted" style="font-weight:800">Alege template</p>
      <div class="list">${state.templates.map(t => `<button type="button" class="secondary template-pick" onclick="createSession('${t.id}', sName.value, sDate.value)"><b>${escapeHtml(t.name)}</b><br><small class="muted">${t.itemIds.length} iteme · ${escapeHtml(t.notes || '')}</small></button>`).join('')}</div>
    </div>`);
}
function createSession(templateId, name='', date='') {
  const t = byId(state.templates, templateId);
  if (!t) return;
  const makeItems = () => t.itemIds.map(gearId => ({ id: uid(), gearId, checked: false }));
  const session = { id: uid(), name: name?.trim() || t.name + ' · ' + today(), templateId, date: date || today(), mode: 'pack', packItems: makeItems(), returnItems: makeItems(), completed: false };
  state.sessions.push(session);
  save(); modal.close(); activeTab = 'sessions'; currentSessionId = session.id; render();
}
function setSessionMode(id, mode) { byId(state.sessions, id).mode = mode; save(); render(); }
function toggleChecklist(sessionId, itemId, mode) {
  const s = byId(state.sessions, sessionId); const arr = mode === 'return' ? s.returnItems : s.packItems; const item = arr.find(i => i.id === itemId);
  item.checked = !item.checked; save(); render();
}
function toggleAll(sessionId, mode, checked) {
  const s = byId(state.sessions, sessionId); const arr = mode === 'return' ? s.returnItems : s.packItems;
  arr.forEach(i => i.checked = checked); save(); render();
}
function completeSession(id) { byId(state.sessions, id).completed = true; save(); render(); }
function deleteSession(id) { if(confirm('Ștergi sesiunea?')) { state.sessions = state.sessions.filter(s => s.id !== id); currentSessionId = null; save(); render(); } }

function exportBackup() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `gear-check-backup-${today()}.json`; a.click();
  URL.revokeObjectURL(url);
}
importFile.addEventListener('change', async e => {
  const file = e.target.files[0]; if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!data.gear || !data.bags || !data.templates) throw new Error('Format invalid');
    if (confirm('Importul va înlocui datele actuale. Continui?')) { state = data; save(); render(); }
  } catch (err) { alert('Backup invalid sau corupt.'); }
  importFile.value = '';
});

if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
render();
